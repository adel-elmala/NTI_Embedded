#ifndef DATATYPES_H
#define DATATYPES_H
#include <stdint.h>

typedef uint8_t uint8;
typedef uint16_t uint16;
typedef uint32_t uint32;
#define NULL (void *)0

#endif