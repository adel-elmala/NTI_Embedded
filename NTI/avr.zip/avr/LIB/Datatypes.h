#ifndef DATATYPES_H
#define DATATYPES_H

typedef unsigned char uint8;

#endif