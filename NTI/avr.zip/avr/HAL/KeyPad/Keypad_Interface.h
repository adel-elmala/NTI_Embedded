#ifndef KEYPAD_INTERFACE_H
#define KEYPAD_INTERFACE_H

#include "../../LIB/Datatypes.h"

void keypad_init(void);
uint8 keypad_GetPress(void);

#endif