#ifndef SPI_INTERFACE_H
#define SPI_INTERFACE_H

void SPI_MasterInit(void);
void SPI_MasterTransmit(char cData);

#endif