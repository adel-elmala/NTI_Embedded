#ifndef GIE_REG_H
#define GIE_REG_H

#define SREG (*((volatile uint8 *)(0x5F)))
#define SREG_GIE 7

#endif