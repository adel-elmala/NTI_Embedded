#ifndef COM_PROJECT_MASTER_H
#define COM_PROJECT_MASTER_H

void project_master_init(void);
void project_master_app(void);

#endif