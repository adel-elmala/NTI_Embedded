#include "../LIB/Datatypes.h"

uint8 Debounce_Check(uint8 Input_Signal);