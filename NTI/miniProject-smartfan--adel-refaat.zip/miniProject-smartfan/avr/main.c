// #include "APP/application.h"
// #include "APP/test.h"
#include "APP/smart_fan.h"

void main()
{
    // testLCD();
    // calc_app();
    // test_timer0();
    // test_pwm();
    // test_adc();
    // test_motor();
    sf_app();
}