#include "APP/application.h"

void main()
{
    // testLCD();
    calc_app();
}