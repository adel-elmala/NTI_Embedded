#ifndef GIE_INTERFACE_H
#define GIE_INTERFACE_H
void _cli(void); // inline asm version
void _sei(void); // inline asm version
void cli(void);
void sei(void);
#endif