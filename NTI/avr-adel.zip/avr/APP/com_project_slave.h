#ifndef COM_PROJECT_SALVE_H
#define COM_PROJECT_SALVE_H

void project_slave_init(void);
void project_slave_app(void);

#endif