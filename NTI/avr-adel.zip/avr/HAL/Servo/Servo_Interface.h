#ifndef SERVO_INTERFACE_H
#define SERVO_INTERFACE_H

#include "../../LIB/Datatypes.h"

void SERVO_Init();
void SERVO_Turn(int degrees);

#endif