#include <stdio.h>
#include <DB.h>

 static Student* DB[] = {{1,"Ahmed Ali"},{2,"Sara Ibrahim"}};

void main()
{
    unsigned int ID;
    char Newname[20];
    int i;
   printf("PLease Enter ID of student\n");
   scanf("%d",&ID);
   printf("Please Enter New Name\n");
   fflush(stdin);
   gets(name);
   ModifyName(ID ,Newname );
   printf("After Modification\n");
   for(i= 0;i<2 ;i++)
   {
       printf("%d\t%s\n",DB[i]->sID,DB[i]->name);
   }
}
