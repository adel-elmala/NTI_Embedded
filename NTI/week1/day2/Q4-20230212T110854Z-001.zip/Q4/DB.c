#include <stdio.h>
#include <DB.h>

extern Student* DB[2] ;
static void ModifyName(unsigned int ID ,char * Newname )
{
  int i ;
  for(i=0;i<2;i++)
  {
      if(ID == DB[i]->sID);
      {
          DB[i]->name = Newname;
      }
  }

}
