#ifndef _DB_H
#define _DB_H
typedef struct dataBaseStudent{
   unsigned int sID;
   char name[20];
}Student;
static void ModifyName(unsigned int indx ,char * Newname );
#endif // _DB_H


